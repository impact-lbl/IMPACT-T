      integer, parameter :: MPI_STATUS_SIZE = 1
      integer, parameter :: MPI_PROC_NULL = 0
      integer :: MPI_DOUBLE_PRECISION,MPI_DOUBLE_COMPLEX
      integer :: MPI_INTEGER,MPI_SUM,MPI_COMM_WORLD
      integer :: MPI_MIN, MPI_MAX
!      double precision :: MPI_WTIME
