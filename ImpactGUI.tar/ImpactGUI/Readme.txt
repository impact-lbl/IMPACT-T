ImpactGUI is a python GUI for the ImpactT and ImpactZ codes.
It can be used on Windows, MAC and Linux/Unix systems.
To use the ImpactGUI, one needs to install 
Pyhon3 Tkinter, Numpy, Scipy and Matplotlib.
To run the Impact code under the GUI, one can either put the executables
of ImpactT (ImpactTexe) and ImpactZ (ImpactZexe) under the
/src directory or use the Advanced Setting menue, exe button to
load the executable into the GUI.
The input files for running the Impact code can be either input
by hand or by using the Load button under the File menue.
